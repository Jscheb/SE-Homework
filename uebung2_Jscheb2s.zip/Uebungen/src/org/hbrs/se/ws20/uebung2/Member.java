package org.hbrs.se.ws20.uebung2;
/*
 * @author Jscheb2s
 */
interface Member { 

	Integer getID();
	
	String toString();

}
 