package org.hbrs.se.ws20.uebung2;
import java.util.ArrayList;
import java.util.List;

/*
 * @author Jscheb2s
 */
public class Container {
	
	public Container() {
	}
	private List<Member> y = new ArrayList<>();
	
	public void addMember ( Member r ) throws ContainerException {
		if (contains(r)) {
			ContainerException ex = new ContainerException();
			ex.addID ( r.getID() );
			throw ex;
		}
		y.add( r );
	} 

	private boolean contains(Member r) {
		Integer ID = r.getID();
		for ( Member rec : y) {
			if ( rec.getID().intValue() == ID.intValue() ) {
				return true;
			}
		}
		return false;
		
	}
	
	public String delete( Integer id ) {
		Member rec = getMember( id );
		if (rec == null) return "Member nicht gefunden - ERROR"; else {
			y.remove(rec);
			return "Member " + id + " wurde geloescht";
		}
	}
	
	public int size(){
		return y.size();
	}
	
	public void dump() {
		System.out.println("Ausgabe aller Member-Objekte: ");
		for (Member p : y) {
			System.out.println("ID: " + p.getID());
		}
	}
	private Member getMember(Integer id) {
		for ( Member rec : y) {
			if (id == rec.getID().intValue() ){
				return rec;
			}
		}
		return null;
	}
}
