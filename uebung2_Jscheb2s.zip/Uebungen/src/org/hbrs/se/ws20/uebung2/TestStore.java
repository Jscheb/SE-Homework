package org.hbrs.se.ws20.uebung2;
/*
 * @author Jscheb2s
 */

class Test {

	public static void main (String[] args)  {
		Test test = new Test();
		try {
			test.start();
		} catch (ContainerException e) {
			e.printStackTrace();
		}

	}
	
public void start() throws ContainerException {
		
		Member T1 = new MemberKonkret(32);
		Member T2 = new MemberKonkret(56);
		Member T3 = new MemberKonkret(422);
		Member T4 = new MemberKonkret(1);
		Member T5 = new MemberKonkret(14);
		Container x = new Container();
				
		
		vergleich ( "Testfall 1 - Pruefung auf leeren Store" , 0 , x.size()  );
		 
		x.addMember( T1 );
		x.addMember( T2 );
		x.addMember( T3 );
		x.addMember( T4 );
		
	
		vergleich ( "Testfall 2 - Prüfen, ob vier Objekte eingefuegt wurden" , 4 , x.size()  );

		x.addMember(T5);
		
		vergleich ( "Testfall 3 - Prüfen, ob fuenftes Objekt eingefuegt wurde" , 5 , x.size()  );
		
		String result = x.delete(32);

		vergleich ( "Testfall 4 - Prüfen, ob Objekt geloescht wurde" ,  4 , x.size()  );
		
		result = x.delete(75463756);
		System.out.println( result );

		vergleich ( "Testfall 5 - Pruefen, ob ein Objekt faelschlicherweise nicht geloescht wurde" , 4 , x.size()  );
		
		try {
			x.addMember( T2 );
		} catch (ContainerException e) {
			e.printStackTrace();
		} finally {
			vergleich ( "Testfall 6 - Pruefen, ob ein Objekt faelschlicherweise nicht doppelt eingefuegt wurde" , 4 , x.size()  );
		}
		
		x.dump();
		
		CloneableMember original = new CloneableMember( 1000 );
		CloneableMember copie = null;
		try {
			copie = ( CloneableMember ) original.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();		
		}

		System.out.println( "Test Identitaet zwischen Original und Kopie: " + ( original == copie)  );
		System.out.println("Falls false: Objekte haben unterschiedliche Speicheradressen! \n");
		x.addMember( copie );

		try {
			x.addMember( original );
		} catch (ContainerException e) {
			
			e.printStackTrace();
		}
		finally {
			vergleich ( "Testfall 7 - Pruefen, ob ein kopiertes Objekt faelschlicherweise nicht doppelt eingefuegt wurde" , 5 , x.size()  );
		}
		x.dump();
	}

	private void vergleich( String xx, int yy , int zz ){
		System.out.print( xx + ": \n");
		if (yy == zz ) {
			System.out.print("Soll (" + yy + ") = IST (" + yy + ") --> Test ERFOLGREICH");
		} else {
			System.out.print("Soll (" + yy + ") != IST (" + yy + ") --> Test NICHT ERFOLGREICH");
		}
		System.out.println("\n");
	}
}
