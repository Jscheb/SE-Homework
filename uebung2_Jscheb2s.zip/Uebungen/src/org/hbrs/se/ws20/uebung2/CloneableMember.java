package org.hbrs.se.ws20.uebung2;

/*
 * @author Jscheb2s
 */

public class CloneableMember implements Member, Cloneable {

	public Integer getID() {
		return this.id;
	}

	protected Object clone() throws CloneNotSupportedException {

		if ( this instanceof Cloneable) {
			return new CloneableMember( this.id );
		} else {
			throw new CloneNotSupportedException();
		}
	}
	
	private Integer id;
	
	public CloneableMember( Integer id ){
		this.id = id;  
	}
	
	public void setID( Integer id ) {
		this.id = id;
	}
	
	@Override
	public String toString() {
		return "CloneableMember [id=" + id + "]";
	} 
	
	
	
 
}
