package org.hbrs.se.ws20.uebung1.test;
/*
  @author Jscheb2s
 */
import org.hbrs.se.ws20.uebung1.control.*;
import org.hbrs.se.ws20.uebung1.view.*;

public class Assembler {

    private Client client = null;
    private Translator translator = null;

    public Assembler() {

        translator = new GermanTranslator();
        client = new Client();

        client.setTranslator( translator );
    }
    public void test(){

        client.display( 1 );
        client.display( 2 );
        client.display( 3 );
        client.display( 4 );
        client.display( 5 );
        client.display( 6 );
        client.display( 7 );
        client.display( 8 );
        client.display( 9 );
        client.display( 10 );
        client.display( 11 );
        client.display( 943959359 );
        client.display( -1 );
    }

    public void testAutomatisiert() {


        String Egebnis = this.translator.translateNumber(1);

        if ( Egebnis.equals("eins") ) {
            System.out.println("Test erfolgreich!");
        } else {
            System.out.println("Test nicht erfolgreich!");
        }

    }

    public static void main(String[] args) {
        Assembler a = new Assembler();
        a.test();
    }

}

