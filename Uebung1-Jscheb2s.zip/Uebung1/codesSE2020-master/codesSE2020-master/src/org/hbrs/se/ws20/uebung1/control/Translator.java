package org.hbrs.se.ws20.uebung1.control;

/*
  @author Jscheb2s
 */

public interface Translator {
	
	double version = 1.9;

	String translateNumber(int number);

} 








