/*
  @author Jscheb2s
 */
package org.hbrs.se.ws20.uebung1.control;

public class GermanTranslator implements Translator {

	private String[] A = { "eins", "zwei", "drei", "vier" , "fünf", "sechs" , "sieben" , "acht" , "neun" , "zehn" };
	private String date;

	public  String translateNumber(int number) {

		String result = "";

		try {
			result = A[ number - 1 ];

		} catch (ArrayIndexOutOfBoundsException e) {
			result = "Übersetzung der Zahl " + number + " ist nicht möglich! (V " + Translator.version + ")";
		}

		return result;
	}

	public void printInfo() {

		System.out.println( "GermanTranslator v1.9, erzeugt am " + this.date );
	}

	public void setDate( String date ) {

		this.date = date;
	}
}
