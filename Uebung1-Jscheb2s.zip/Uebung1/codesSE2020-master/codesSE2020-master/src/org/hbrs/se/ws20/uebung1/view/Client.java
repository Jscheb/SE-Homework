/*
  @author Jscheb2s
 */
package org.hbrs.se.ws20.uebung1.view;
import org.hbrs.se.ws20.uebung1.control.Translator;
import org.hbrs.se.ws20.uebung1.control.GermanTranslator;
import org.hbrs.se.ws20.uebung1.control.Factory;

public class Client extends GermanTranslator {

	public Client() {
	}
	Translator translator = null;

	public void display(int aNumber) {


		System.out.println("Das Ergebnis zu: " + aNumber + ": " + translateNumber(aNumber) );

	}

	public void setTranslator(Translator translator) {
		this.translator = translator;
	}
}

